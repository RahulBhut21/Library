<!doctype html>
<html dir="ltr" lang="en-US">

<head>
    <title>UCPlaces</title>
    <link type="image/x-icon" rel="shortcut icon" href="assets/images/favicon.png" />
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link type="text/css" rel="stylesheet" href="assets/css/all.min.css" />
    <link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="assets/css/style.css" />
    <link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>

    <section class="login-section">
        <div class="desk-view">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 order-12">
                        <div class="login-wrapper">
                            <div class="max-login-width">

                                <!-- Logo Row -->
                                <div class="d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <img src="assets/images/ucplogo.png" alt="ucplace-logo" class="logo">
                                    </div>
                                    <div>
                                        <a href="javascript:void(0)" class="go-home-badge">
                                            Go to Home
                                        </a>
                                    </div>
                                </div>

                                <!-- Login -->
                                <div class="login-box">
                                    <div>
                                        <h1>Login</h1>
                                        <lable class="heading-subtitle">Please Login to your account and continue with UCPlaces.</lable>
                                    </div>

                                    <div class="login-form">
                                        <form>
                                            <div class="form-group">
                                                <label for="getMail">Email ID</label>
                                                <input type="email" class="form-control" id="getMail" placeholder="Type email id here" required />
                                            </div>
                                            <div class="form-group">
                                                <label for="getPassword">Password</label>
                                                <input type="password" class="form-control" id="getPassword" placeholder="Type password here" required />
                                                <!-- <i class="fas fa-eye eye"></i>-->
                                                <i class="fas fa-eye-slash eye"></i>
                                            </div>
                                            <div class="text-right">
                                                <a href="javascript:void(0)"><label class="forget">Forget Password?</label></a>
                                            </div>
                                            <div>
                                                <button type="submit" class="btn w-100 btn-enter">login</button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="or-login-option">
                                        <div class="or-label mb-4">
                                            <span>or</span>
                                        </div>
                                        <div class="social-login-btns-group d-flex flex-row align-items-center justify-content-between">
                                            <div class="login-btn login-facebook">
                                                <div class="login-opt-icon">
                                                    <i class="fab fa-facebook-f"></i>
                                                </div>
                                                <div class="social-text">
                                                    Facebook
                                                </div>
                                            </div>
                                            <div class="login-btn login-google">
                                                <div class="login-opt-icon">
                                                    <i class="fab fa-google"></i>
                                                </div>
                                                <div class="social-text">
                                                    Google
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!-- Don't have an account -->
                                <div class="no-account w-100 text-center font-weight-bold">
                                    <lable class="last-row ">Don't have an account? <a href="javascript:void(0)">Signup</a></lable>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 order-lg-12">
                        <div class="no-margin-row">
                            <div class="bg-full">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-view">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="no-margin-row">
                            <div class="bg-full">
                                <div class="login-wrapper">
                                    <div class="max-login-width">

                                        <!-- Logo Row -->
                                        <div class="d-flex flex-row align-items-center justify-content-between">
                                            <div>
                                                <img src="assets/images/ucplogo.png" alt="ucplace-logo" class="logo">
                                            </div>
                                            <div>
                                                <a href="javascript:void(0)" class="go-home-badge">
                                                    Go to Home
                                                </a>
                                            </div>
                                        </div>

                                        <!-- Login -->
                                        <div class="login-box">
                                            <div>
                                                <h1>Login</h1>
                                                <lable class="heading-subtitle">Please Login to your account and continue with UCPlaces.</lable>
                                            </div>

                                            <div class="login-form">
                                                <form>
                                                    <div class="form-group">
                                                        <label for="getMail">Email ID</label>
                                                        <input type="email" class="form-control" id="getMail" placeholder="Type email id here" required />
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="getPassword">Password</label>
                                                        <input type="password" class="form-control" id="getPassword" placeholder="Type password here" required />
                                                        <!-- <i class="fas fa-eye eye"></i>-->
                                                        <i class="fas fa-eye-slash eye"></i>
                                                    </div>
                                                    <div class="text-right">
                                                        <a href="javascript:void(0)"><label class="forget">Forget Password?</label></a>
                                                    </div>
                                                    <div>
                                                        <button type="submit" class="btn w-100 btn-enter">login</button>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="or-login-option">
                                                <div class="or-label mb-4">
                                                    <span>or</span>
                                                </div>
                                                <div class="social-login-btns-group d-flex flex-row align-items-center justify-content-between">
                                                    <div class="login-btn login-facebook">
                                                        <div class="login-opt-icon">
                                                            <i class="fab fa-facebook-f"></i>
                                                        </div>
                                                        <div class="social-text">
                                                            Facebook
                                                        </div>
                                                    </div>
                                                    <div class="login-btn login-google">
                                                        <div class="login-opt-icon">
                                                            <i class="fab fa-google"></i>
                                                        </div>
                                                        <div class="social-text">
                                                            Google
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <!-- Don't have an account -->
                                        <div class="no-account w-100 text-center font-weight-bold">
                                            <lable class="last-row ">Don't have an account? <a href="javascript:void(0)">Signup</a></lable>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/custom.js"></script>
</body>

</html>
