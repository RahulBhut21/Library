function hindilangchange(){
    $("#langhome").html("होम");
    $(".langabout").html("के बारे में");
    $("#langaboutus").html("हमारे बारे में");
    $("#langmember").html("सदस्य");
    $("#langpathshala").html("पाठशाला");
    $("#langalumni").html("पूर्व छात्रों");
    $("#langgallery").html("गेलरी");
    $("#langblog").html("ब्लॉग");
    $("#langadmission").html("दाखिला");
    $(".langcontact").html("संपर्क करें");
    $("#langcontactus").html("हमसे संपर्क करें");
}

function gujratilangchange(){
    $("#langhome").html("ઘર");
    $(".langabout").html("વિશે");
    $("#langaboutus").html("અમારા વિશે");
    $("#langmember").html("સભ્યો");
    $("#langpathshala").html("શાળા");
    $("#langalumni").html("ભૂતપૂર્વ વિદ્યાર્થી");
    $("#langgallery").html("ગેલેરી");
    $("#langblog").html("બ્લોગ");
    $("#langadmission").html("પ્રવેશ");
    $(".langcontact").html("સંપર્ક કરો");
    $("#langcontactus").html("અમારો સંપર્ક કરો");
}